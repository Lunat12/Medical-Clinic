from django import forms
from .models import Date, Speciality

class NewDate(forms.ModelForm):
    class Meta:
        model = Date
        fields = ["date"]
        widgets ={
            "date":forms.TextInput(attrs={"type":"datetime-local"})
        }
        
    speciality = forms.ModelChoiceField(queryset=Speciality.objects.all(),to_field_name="name")