from django.contrib import admin
from .models import Date, Speciality, Doctors

admin.site.register(Date)
admin.site.register(Speciality)
admin.site.register(Doctors)