from django.shortcuts import render, redirect
from .models import Date, Speciality, Doctors
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import logout, get_user_model
from .forms import NewDate
import random
from datetime import datetime

# Create your views here.

@login_required
def my_appointments(request):
    appointments = []
    my_appointments = []
    
    for appointment in Date.objects.all():
        if appointment.is_today() and appointment.doctors.doctors == request.user:
            appointments.append(appointment)
        if appointment.is_passed() == False and appointment.patient == request.user:
            my_appointments.append(appointment)
            
    
    context = {
        "appointments" : appointments,
        "my_appointments" : my_appointments,
    }
    
    return render(request, "my_appointments.html", context=context)

@login_required
@permission_required("appointments.is_patient")
def delete_appointment(request, pk):
    appointment = Date.objects.get(pk=pk)
    appointment.delete()
    return redirect('appointments')

@login_required
@permission_required("appointments.is_patient")
def new_appointment(request):
    
    
    sent = ""
    if request.method == "POST":
        
        form = NewDate(request.POST)
        
        if form.is_valid():
            try:
                dateEje = Date.objects.get(pk=1)
                date=Date()
                date.date = form.cleaned_data["date"]
                doctors = Doctors.objects.filter(speciality = form.cleaned_data["speciality"])
                date.doctors = doctors[random.randint(0, len(doctors)-1)]
                date.patient = request.user
                date.save()
                sent = "Appointment saved"
                return redirect('appointments')
            except:
                sent = "There was an error while saving"
        else:
            sent = "Unvalid Info."
    form = NewDate()
    
    

    context = {
        
        "form":form,
        "sent":sent,
    }
    
    return render(request, "new_appointment.html", context=context)