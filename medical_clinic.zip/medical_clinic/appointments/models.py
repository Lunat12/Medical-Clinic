from django.db import models
from django.urls import reverse
from datetime import date

# Create your models here.
class Doctors(models.Model):
    doctors = models.ForeignKey('auth.user', related_name= "date_doctors", on_delete=models.SET_NULL, null=True, blank=True)
    speciality = models.ForeignKey('Speciality', related_name= "date_speciality", on_delete=models.SET_NULL, null=True, blank=True)
  
class Date(models.Model):
    patient = models.ForeignKey('auth.user', related_name="date_patient", on_delete=models.SET_NULL, null=True, blank=True)
    doctors = models.ForeignKey(Doctors, related_name= "date_doctors", on_delete=models.SET_NULL, null=True, blank=True)
    date = models.DateTimeField()
    
    def is_passed(self):
        return date.today() > self.date.date()
    
    def is_today(self):
        return date.today() == self.date.date()
    
    class Meta:
        permissions = (('is_doctor', 'Works_here'), ("is_patient", "can_ask"))
    
    def get_absolute_url_1(self):
        return reverse('delete_appointment', args=[str(self.id)])
    
class Speciality(models.Model):
    name = models.CharField(max_length=200)
    
    def __str__(self):
        return self.name
    
