from django.urls import path
from . import views

urlpatterns = [
    path("", views.my_appointments, name= "appointments" ),
    path("appointment/<int:pk>/delete", views.delete_appointment, name= "delete_appointment" ),
    path("appointment/new", views.new_appointment, name= "new_appointment" ),
]