from django.db import models
from django.urls import reverse

# Create your models here.
class Question(models.Model):
   
    patient = models.ForeignKey('auth.user', on_delete=models.SET_NULL, null=True, blank=True)
    title = models.CharField(max_length=200)
    body = models.TextField(max_length=1000)
    response = models.TextField(max_length=1000, null=True, blank=True)
    answered = models.BooleanField(default=False)
        
    def __str__(self):
        return self.title
    
    def get_absolute_url_1(self):
        return reverse('question_detail', args=[str(self.id)])
    