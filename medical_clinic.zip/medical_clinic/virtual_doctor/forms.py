from django import forms

class Respond(forms.Form):
    response = forms.CharField(label = 'Response', max_length = 1000,
                              widget=forms.TextInput(attrs={"class":"form-control"}))
    
class NewQuestion(forms.Form):
    title = forms.CharField(label = 'Question Title', max_length = 200,
                              widget=forms.TextInput(attrs={"class":"form-control"}))
    body = forms.CharField(label = 'Question', max_length = 200,
                              widget=forms.TextInput(attrs={"class":"form-control"}))