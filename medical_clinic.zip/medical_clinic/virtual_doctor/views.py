from django.shortcuts import render
from .models import Question
from django.contrib.auth.decorators import login_required, permission_required
from .forms import Respond, NewQuestion
from django.shortcuts import redirect

@login_required
def questions(request):
    questions = Question.objects.filter(answered = False);
    
    my_questions = Question.objects.filter(patient = request.user.id)
    
    context = {
        "questions" : questions,
        "my_questions" : my_questions,
    }
    
    return render(request, "questions.html", context=context)

@login_required
@permission_required("appointments.is_patient")
def new_question(request):
    sent = ""
    if request.method == "POST":
        form = NewQuestion(request.POST)
        if form.is_valid():
            try:
                question = Question()
                question.title = form.cleaned_data["title"]
                question.body = form.cleaned_data["body"]
                question.patient = request.user
                question.save()
                sent = "Your infomation was saved succesfully"
                return redirect('questions')
            except:
                sent = "There was a problem while saving."
        else:
            sent = "Unvalid Info."
    form = NewQuestion()     
    
    
    context = {
        
        "form":form,
        "sent":sent,
    }
    
    return render(request, "new_question.html", context=context)

@login_required
def question_detail(request, pk):
    question = Question.objects.get(pk=pk)
    
    sent = ""
    if request.method == "POST":
        form = Respond(request.POST)
        if form.is_valid():
            try:
                question.response = form.cleaned_data["response"]
                question.answered = True
                question.save()
                return redirect('questions')
                sent = "Your infomation was saved succesfully"
            except:
                sent = "There was a problem while saving."
        else:
            sent = "Unvalid Info."
    form = Respond()     

    context = {
        "question" : question,
        "send" : sent,
        "form":form,
    }
    
    return render(request, "question_detail.html", context=context)

