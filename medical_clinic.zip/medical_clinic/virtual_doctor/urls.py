from django.urls import path
from . import views

urlpatterns = [
    path("", views.questions, name= "questions" ),
    path("question/<int:pk>", views.question_detail, name= "question_detail" ),
    path("new/question", views.new_question, name="new_question"),
]