from django.apps import AppConfig


class VirtualDoctorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'virtual_doctor'
